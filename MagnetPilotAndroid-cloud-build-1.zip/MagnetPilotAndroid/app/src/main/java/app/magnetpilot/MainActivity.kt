package app.magnetpilot

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {
    private lateinit var query: EditText
    private lateinit var sourcesView: ListView
    private lateinit var hint: TextView
    private val prefs by lazy { getSharedPreferences("sources", MODE_PRIVATE) }
    private val sources = mutableListOf<SearchSource>()
    private val tasks = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        query = findViewById(R.id.queryInput)
        sourcesView = findViewById(R.id.sourceList)
        hint = findViewById(R.id.sourceHint)
        loadSources()
        renderSources()

        findViewById<Button>(R.id.searchButton).setOnClickListener { search() }
        findViewById<Button>(R.id.addMagnetButton).setOnClickListener { addMagnet(query.text.toString().trim()) }
        findViewById<TextView>(R.id.manageSources).setOnClickListener { addSourceDialog() }
        findViewById<TextView>(R.id.tasksTab).setOnClickListener { showTasks() }
        findViewById<TextView>(R.id.homeTab).setOnClickListener { renderSources() }
        sourcesView.setOnItemClickListener { _, _, position, _ ->
            val source = sources.getOrNull(position) ?: return@setOnItemClickListener
            val q = query.text.toString().trim()
            if (q.isBlank()) { toast("请先输入搜索关键词"); return@setOnItemClickListener }
            openSearch(source.urlTemplate.replace("{query}", URLEncoder.encode(q, "UTF-8")))
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent) }

    private fun handleIntent(intent: Intent?) {
        val raw = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.dataString
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            else -> null
        }?.trim() ?: return
        if (raw.startsWith("magnet:", true) || raw.endsWith(".torrent", true)) {
            query.setText(raw)
            if (raw.startsWith("magnet:", true)) addMagnet(raw)
        } else if (raw.isNotBlank()) query.setText(raw)
    }

    private fun search() {
        val q = query.text.toString().trim()
        if (q.isBlank()) { toast("请输入关键词"); return }
        if (q.startsWith("magnet:", true)) { addMagnet(q); return }
        if (sources.isEmpty()) { addSourceDialog(); return }
        if (sources.size == 1) {
            openSearch(sources[0].urlTemplate.replace("{query}", URLEncoder.encode(q, "UTF-8")))
        } else {
            AlertDialog.Builder(this).setTitle("选择搜索源")
                .setItems(sources.map { it.name }.toTypedArray()) { _, which ->
                    openSearch(sources[which].urlTemplate.replace("{query}", URLEncoder.encode(q, "UTF-8")))
                }.show()
        }
    }

    private fun openSearch(url: String) {
        if (!url.startsWith("https://")) { toast("出于安全考虑，仅允许 HTTPS 搜索源"); return }
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun addMagnet(raw: String) {
        if (!raw.startsWith("magnet:?xt=urn:btih:", true) && !raw.startsWith("magnet:", true)) {
            toast("请输入有效的 magnet 链接"); return
        }
        lifecycleScope.launch {
            try {
                TorrentEngine.add(this@MainActivity, raw)
                tasks.add(0, raw)
                toast("已提交 BT 下载引擎")
            } catch (e: Exception) {
                toast("BT 引擎初始化失败：${e.message ?: "请检查依赖版本"}")
            }
        }
    }

    private fun showTasks() {
        if (tasks.isEmpty()) {
            AlertDialog.Builder(this).setTitle("下载任务")
                .setMessage("当前会话暂无任务。粘贴 magnet 链接后点击“添加磁力任务”。\n\n完整的持久化任务队列、速度与进度轮询需要在设备构建测试中完成。")
                .setPositiveButton("知道了", null).show()
        } else {
            AlertDialog.Builder(this).setTitle("本次会话任务")
                .setItems(tasks.toTypedArray(), null).setPositiveButton("关闭", null).show()
        }
    }

    private fun addSourceDialog() {
        val name = EditText(this).apply { hint = "搜索源名称（如：公开索引）" }
        val url = EditText(this).apply {
            hint = "HTTPS URL 模板，关键词用 {query} 表示"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 12, 48, 0)
            addView(name); addView(url)
        }
        AlertDialog.Builder(this).setTitle("添加搜索源").setView(box)
            .setMessage("请仅添加你有权访问的合法公开索引网站。示例格式：https://example.org/search?q={query}")
            .setNegativeButton("取消", null).setPositiveButton("保存") { _, _ ->
                val n = name.text.toString().trim()
                val u = url.text.toString().trim()
                if (n.isBlank() || !u.startsWith("https://") || !u.contains("{query}")) {
                    toast("名称不能为空，网址必须为 HTTPS 并包含 {query}"); return@setPositiveButton
                }
                sources.add(SearchSource(n, u)); saveSources(); renderSources()
            }.show()
    }

    private fun loadSources() {
        val raw = prefs.getString("items", "") ?: ""
        raw.lineSequence().filter { it.contains("\t") }.forEach {
            val p = it.split("\t", limit = 2)
            if (p.size == 2) sources.add(SearchSource(p[0], p[1]))
        }
    }
    private fun saveSources() {
        prefs.edit().putString("items", sources.joinToString("\n") { "${it.name}\t${it.urlTemplate}" }).apply()
    }
    private fun renderSources() {
        sourcesView.adapter = object : ArrayAdapter<SearchSource>(this, android.R.layout.simple_list_item_2, android.R.id.text1, sources) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                val item = getItem(position)!!
                v.findViewById<TextView>(android.R.id.text1).apply { text = "⌕  ${item.name}"; setTextColor(0xFFF3F5FF.toInt()); textSize = 16f }
                v.findViewById<TextView>(android.R.id.text2).apply { text = item.urlTemplate; setTextColor(0xFF8E97B2.toInt()); textSize = 11f }
                return v
            }
        }
        hint.text = if (sources.isEmpty()) "还没有搜索源。点击右上角「管理 +」添加你有权访问的公开索引网站。" else "点击一个搜索源打开搜索结果。长按可管理来源。"
        sourcesView.setOnItemLongClickListener { _, _, pos, _ ->
            AlertDialog.Builder(this).setItems(arrayOf("删除搜索源")) { _, _ ->
                sources.removeAt(pos); saveSources(); renderSources()
            }.show(); true
        }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
data class SearchSource(val name: String, val urlTemplate: String)
