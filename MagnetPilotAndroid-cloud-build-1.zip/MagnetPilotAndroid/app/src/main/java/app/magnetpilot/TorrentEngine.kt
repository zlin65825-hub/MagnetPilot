package app.magnetpilot

import android.content.Context
import org.libtorrent4j.AddTorrentParams
import org.libtorrent4j.SessionManager
import java.io.File

/**
 * BT engine adapter. API compatibility must be checked against the chosen libtorrent4j release.
 * This singleton intentionally keeps the session alive for the process lifetime; a production build
 * should move it to a foreground service with notification + durable task database.
 */
object TorrentEngine {
    @Volatile private var manager: SessionManager? = null

    @Synchronized
    fun add(context: Context, magnet: String) {
        val session = manager ?: SessionManager().also {
            it.start()
            manager = it
        }
        val downloadDir = File(context.getExternalFilesDir(null), "downloads")
        if (!downloadDir.exists() && !downloadDir.mkdirs()) error("无法创建下载目录")
        val params = AddTorrentParams.parseMagnetUri(magnet)
        params.savePath = downloadDir.absolutePath
        session.download(params)
    }
}
