# MagnetPilot（磁力搜索与下载）Android 项目

这是一个原生 Android Studio 工程骨架，目标为 Android 8.0+，深色中文界面。

## 当前工程包含
- 深色首页、关键词搜索入口、可配置搜索源列表
- 自定义搜索源的添加/删除与本地持久化
- 磁力链接粘贴/识别入口
- 下载任务页与任务状态展示框架
- Android Sharesheet / `ACTION_VIEW` 接收 `magnet:` URI
- libtorrent4j Android 依赖与 BT 下载服务接入点

## 重要说明
本执行环境没有 Android SDK、Gradle 可执行安装或 Android 构建缓存，因此这里无法实际编译、签名、安装和验证 APK。此交付是 Android Studio 源码项目，不是已构建 APK。请在安装 Android Studio、Android SDK（API 35）与 JDK 17 的电脑上打开工程并执行 Gradle Sync / Build。

## 搜索源
各站点页面结构不同，不能仅凭一个通用 URL 模板保证自动提取所有结果。当前版本允许配置搜索网站 URL 模板（用 `{query}` 表示关键词），并在应用内打开页面。若要做可靠的聚合搜索，需要针对每个合法公开源编写和维护适配器，遵守站点条款、robots 规则和访问限制。

## BT 下载引擎
项目声明了 libtorrent4j Android ARM/ARM64 依赖，并在 `TorrentEngine.kt` 中集中封装。不同版本的 libtorrent4j API/原生库发布方式可能有差异，首次构建需按所选依赖版本验证 API 和 ABI；本环境未完成编译验证。


## 在手机上通过 GitHub Actions 尝试云端编译
1. 在 GitHub 创建仓库。手机浏览器可选择“桌面版网站”以便看见完整菜单。
2. 上传本项目所有文件，尤其是 `.github/workflows/build-apk.yml`（上传时要确保隐藏目录 `.github` 也上传）。
3. 等待 `Actions` 工作流运行。成功后进入对应运行记录底部的 `Artifacts`，下载 `magnetpilot-debug-apk` 并解压取得 APK。
4. 这是 debug 测试包，不是正式发布签名包。若构建失败，打开运行记录并查看失败步骤的日志；首次构建可能需要修复依赖或 Kotlin/API 编译问题。

注意：GitHub Actions 只能执行构建，并不保证未验证源码一定成功。当前项目仍属于早期原型。
